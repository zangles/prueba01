<?php

namespace App\Http\Controllers;

use App\Models\Webs;
use Illuminate\Http\Request;

class WebControllers extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\Webs  $webs
     * @return \Illuminate\Http\Response
     */
    public function show(Webs $webs)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\Webs  $webs
     * @return \Illuminate\Http\Response
     */
    public function edit(Webs $webs)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\Webs  $webs
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Webs $webs)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\Webs  $webs
     * @return \Illuminate\Http\Response
     */
    public function destroy(Webs $webs)
    {
        //
    }
}
