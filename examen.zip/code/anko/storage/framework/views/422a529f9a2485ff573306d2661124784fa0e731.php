<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-10">
            <div class="card">
                <div class="card-header">Lista Empleados</div>

                <div class="card-body">
                    <table class="table table-striped">
                        <thead>
                        <tr>
                            <th scope="col">Id Legajo</th>
                            <th scope="col">Nombre Completo</th>
                            <th scope="col">Direccion</th>
                            <th scope="col">Localidad</th>
                            <th scope="col">Documento</th>
                            <th scope="col">Codigo Postal</th>
                            <th scope="col">Pronvicia</th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php $__currentLoopData = $empleados; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $empleado): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <th scope="row"><?php echo e($empleado->id_legajo); ?></th>
                                <td><?php echo e($empleado->nombre); ?> <?php echo e($empleado->Apellido); ?></td>
                                <td><?php echo e($empleado->direccion); ?></td>
                                <td><?php echo e($empleado->localidad); ?></td>
                                <td><?php echo e($empleado->tipoDocumento->tipo_documento); ?> <?php echo e($empleado->nro_documento); ?></td>
                                <td><?php echo e($empleado->codigo_postal); ?></td>
                                <td><?php echo e($empleado->provincia->provincia); ?></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/resources/views/empleados/index.blade.php ENDPATH**/ ?>