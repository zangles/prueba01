<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">Alta Empleado</div>
                <?php if($errors->any()): ?>
                    <div class="alert alert-danger" role="alert">
                        <p>Por favor corrige los errores:</p>
                        <ul>
                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><?php echo e($error); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
                <?php endif; ?>
                <div class="card-body">
                    <form method="POST" action="<?php echo e(route('empleados.store')); ?>">
                        <?php echo csrf_field(); ?>
                        <div class="form-group">
                            <label for="id_legajo">Id Legajo</label>
                            <input type="number" class="form-control" aria-describedby="emailHelp" name="id_legajo" id="id_legajo" value="<?php echo e(old('id_legajo')); ?>" >
                        </div>
                        <div class="form-group">
                            <label for="apellido">Apellido</label>
                            <input type="text" class="form-control" aria-describedby="emailHelp" name="apellido" id="apellido"  value="<?php echo e(old('apellido')); ?>">
                        </div>
                        <div class="form-group">
                            <label for="nombre">Nombre</label>
                            <input type="text" class="form-control" aria-describedby="emailHelp" name="nombre" id="nombre" value="<?php echo e(old('nombre')); ?>">
                        </div>
                        <div class="form-group">
                            <label for="direccion">Direccion</label>
                            <input type="text" class="form-control" aria-describedby="emailHelp" name="direccion" id="direccion" value="<?php echo e(old('direccion')); ?>">
                        </div>
                        <div class="form-group">
                            <label for="localidad">Localidad</label>
                            <input type="text" class="form-control" aria-describedby="emailHelp" name="localidad" id="localidad" value="<?php echo e(old('localidad')); ?>">
                        </div>
                        <div class="form-group">
                            <label for="id_tipo_documento">Tipo Documento</label>
                            <select class="form-control" id="id_tipo_documento" name="id_tipo_documento">
                                <?php $__currentLoopData = $documentos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $document): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($document->id_tipo_documento); ?>"><?php echo e($document->tipo_documento); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        <div class="form-group">
                            <label for="nro_documento">Nro Documento</label>
                            <input type="text" class="form-control" aria-describedby="emailHelp" name="nro_documento" id="nro_documento" value="<?php echo e(old('nro_documento')); ?>">
                        </div>
                        <div class="form-group">
                            <label for="codigo_postal">Codigo Postal</label>
                            <input type="text" class="form-control" aria-describedby="emailHelp" name="codigo_postal" id="codigo_postal" value="<?php echo e(old('codigo_postal')); ?>">
                        </div>
                        <div class="form-group">
                            <label for="id_provincia">Provincia</label>
                            <select class="form-control" id="id_provincia" name="id_provincia">
                                <?php $__currentLoopData = $provincias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $provincia): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($provincia->id_provincia); ?>"><?php echo e($provincia->provincia); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>

                        <button type="submit" class="btn btn-primary">Alta</button>
                        <a href="<?php echo e(route('empleados.index')); ?>" class="btn btn-danger">Salir</a>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/resources/views/empleados/create.blade.php ENDPATH**/ ?>